
    const temperatureHeading = document.querySelector("#temperature");
    console.log(temperatureHeading);


fetch(
  "https://api.openweathermap.org/data/2.5/weather?q=Tel-aviv&units=metric&appid=edf8076fe4c0ad0be362d3875be7acf7"
)
  .then((res) => res.json())
  .then((data) => {
    let temperature = data.main.temp;
    temperature = temperature.toFixed(0);
    console.log(temperature);
    temperatureHeading.innerHTML = `${temperature} °C`;
  });
